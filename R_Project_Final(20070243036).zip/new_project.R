#set libraries
library(tidyverse)
library(sp)
library(tmap)
library(leaflet)
library(ggplot2)
library(sf)
library(stringr)
library(raster)
library(rgdal)
library(rgeos)
library(dplyr)
library(htmltools)
library(leaflet.extras)
library(rnaturalearth)
library(maps)
library(mapproj)

#Set path
setwd("C:\\Users\\dell\\Desktop\\Rajat_Mini_Project\\NEW(PROJECT)")
#load shape file
mapData <- readOGR(choose.files(caption = "Select Shapfile",multi = FALSE))
View(mapData)
plot(mapData)


summary(mapData)


#load csv
demo <- read.csv("Schools, Colleges - Enrollment and Seats (1).csv")
#View
View(demo)
#list the column headings
names(demo)
#head
head(demo)
#mean
mean(demo)
#no of rows
nrow(demo)
#no of columns
ncol(demo)


#histogram of columns from main file
hist(demo$Primary.Schools)
hist(demo$Primary.Schools.Enrollment)
hist(demo$Model.Schools)
hist(demo$Model.Schools.Enrollment)
hist(demo$High.Schools)
hist(demo$High.Schools.Enrollment)
hist(demo$Model.Schools)
hist(demo$Model.Schools.Enrollment)
hist(demo$Engineering.Colleges)
hist(demo$Pharmacy.Colleges)
hist(demo$MBA.Colleges)
hist(demo$MCA.Colleges)
hist(demo$B.Ed..Colleges)
hist(demo$Law.Colleges)
hist(demo$Males)
hist(demo$Total)
hist(demo$Females)
hist(demo$Longititude)
hist(demo$Latitude)


#creating histograms 
hist(demo$Primary.Schools,breaks=20,col="blue",main="primaryschools",xlab="no_of_primaryschools")
hist(demo$Model.Schools,breaks=20,col="blue",main="ModelSchools",xlab="no_of_model_schools")
hist(demo$Central.Schools,breaks=20,col="blue",main="CentralSchools",xlab="no_of_central_school")
hist(demo$Engineering.Colleges,breaks=20,col="blue",main="No_of_EngineeringCollege",xlab="no_of_Engg_colleges")
hist(demo$Pharmacy.Colleges,breaks=20,col="blue",main="No_of_PharmacyCollege",xlab="no_of_Pharmacy_colleges")
hist(demo$MBA.Colleges,breaks=20,col="blue",main="No_of_MBAcollege",xlab="no_of_mba_colleges")
hist(demo$MCA.Colleges,breaks=20,col="blue",main="No_of_MCAcollege",xlab="no_of_mca_colleges")
hist(demo$B.Ed..Colleges,breaks=20,col="blue",main="No_of_B.Ed..Colleges",xlab="no_of_B.Ed..Colleges")
hist(demo$Law.Colleges,breaks=20,col="blue",main="No_of_Law.Colleges",xlab="no_of_Law.Colleges")



#class variables
ggplot(data = demo) +
  geom_point(mapping = aes(y = distname, x = Primary.Schools, color = distname))

ggplot(data = demo) +
  geom_point(mapping = aes(y = distname, x = Primary.Schools.Enrollment, color = distname))

ggplot(data = demo) +
  geom_point(mapping = aes(y = distname, x = Model.Schools, color = distname))

ggplot(data = demo) +
  geom_point(mapping = aes(y = distname, x = Central.Schools.Enrollment, color = distname))

ggplot(data = demo) +
  geom_point(mapping = aes(y = distname, x = Pharmacy.Colleges, color = distname))

ggplot(data = demo) +
  geom_point(mapping = aes(y = distname, x = MBA.Colleges, color = distname))

ggplot(data = demo) +
  geom_point(mapping = aes(y = distname, x = MCA.Colleges, color = distname))

ggplot(data = demo) +
  geom_point(mapping = aes(y = distname, x = Law.Colleges, color = distname))

ggplot(data = demo) +
  geom_point(mapping = aes(y = distname, x = B.Ed..Colleges, color = distname))


#geom_point
ggplot(data = demo) +
  geom_point(mapping = aes(x = Males, y = Females))
#geom_smooth
ggplot(data = demo) +
  geom_smooth(mapping = aes(x = Males, y = Females))

#multi geom point
ggplot(data = demo) +
  geom_point(mapping = aes(x = Males, y = Females)) +
  geom_smooth(mapping = aes(x = Males, y = Females))

#position adjustment representation of enginnerng colleges
ggplot(data = demo) +
  geom_bar(mapping = aes(x = Engineering.Colleges, fill = distname))

#box plot presentation
ggplot(data = demo, mapping = aes(x = Males, y = Females))+
  geom_boxplot() + 
  coord_flip()

#quick load map
transmapplot <- readOGR(choose.files(caption = "Select Shapefile",multi = FALSE))
ggplot(transmapplot,aes(long,lat,group=group))+
  geom_polygon(fill="grey",colour="blue")

ggplot(transmapplot,aes(long,lat,group=group))+
  geom_polygon(fill="grey",colour="blue")+
  coord_quickmap()



#selecting of Schools
demo_1 <- select(demo,"objectid","distname","Primary.Schools","Model.Schools","Central.Schools")
demo_1[is.na(demo_1)]=0
View(demo_1)

#loading shapefile
mapData <- readOGR(choose.files(caption = "Select Shapfile",multi = FALSE))
mapData <- mapData[,1:1]
plot(mapData)
View(mapData)


mergedshp_csv <- merge(mapData,demo_1,by.x="objectid",by.y = "objectid")
View(mergedshp_csv)
qtm(mergedshp_csv, fill = "Primary.Schools",text ="distname",text.size = 0.55,text.col = "black")
qtm(mergedshp_csv, fill = "Model.Schools",text ="distname",text.size = 0.55,text.col = "black")
qtm(mergedshp_csv, fill = "Central.Schools",text ="distname",text.size = 0.55,text.col = "black")
tm_shape(mergedshp_csv) + tm_fill("Primary.Schools",palette = "-Reds",style = "quantile",title = "Primary.Schools")+ tm_text("distname", size = 0.6,  auto.placement = F, legend.size.show = FALSE)+ tm_borders(alpha = .4)+ tm_compass()+   tm_layout(title = "Primary Schools in Telangana",legend.text.size = 1.1,legend.title.size = 1.4, legend.position = c("right","top"), frame = FALSE)
tm_shape(mergedshp_csv) + tm_fill("Model.Schools",palette = "-Reds",style = "quantile",title = "Model.Schools")+ tm_borders(alpha = .4)+ tm_compass()+   tm_layout(title = "Model Schools in Telangana",legend.text.size = 1.1,legend.title.size = 1.4, legend.position = c("right","top"), frame = FALSE)
tm_shape(mergedshp_csv) + tm_fill("Central.Schools",palette = "-Reds",style = "quantile",title = "Central.Schools")+ tm_borders(alpha = .4)+ tm_compass()+   tm_layout(title = "Central Schools in Telangana",legend.text.size = 1.1,legend.title.size = 1.4, legend.position = c("right","top"), frame = FALSE)

#selecting for another data plotting(School Enrolments)
demo_2 <- select(demo,"objectid","distname","Primary.Schools.Enrollment","Model.Schools.Enrollment","Central.Schools.Enrollment")
demo_2[is.na(demo_2)]=0
View(demo_2)


#merge central.schools & primary schools & model schools enrollment
mergedshp_csv2 <- merge(mapData, demo_2, by.x="objectid", by.y = "objectid")
View(mergedshp_csv2)
qtm(mergedshp_csv2, fill = "Primary.Schools.Enrollment")
qtm(mergedshp_csv2, fill = "Model.Schools.Enrollment")
qtm(mergedshp_csv2, fill = "Central.Schools.Enrollment")
tm_shape(mergedshp_csv2) + tm_fill("Primary.Schools.Enrollment",palette = "Greens",style = "quantile",title = "Primary.Schools.Enrollment")+ tm_borders(alpha = .4)+ tm_compass()+   tm_layout(title = "Primary School Enrollment",legend.text.size = 1.1,legend.title.size = 1.4, legend.position = c("right","top"), frame = FALSE)
tm_shape(mergedshp_csv2) + tm_fill("Model.Schools.Enrollment",palette = "Greens",style = "quantile",title = "Model.Schools.Enrollment")+ tm_borders(alpha = .4)+ tm_compass()+   tm_layout(title = "Model School Enrollment",legend.text.size = 1.1,legend.title.size = 1.4, legend.position = c("right","top"), frame = FALSE)
tm_shape(mergedshp_csv2) + tm_fill("Central.Schools.Enrollment",palette = "Greens",style = "quantile",title = "Central.Schools.Enrollment")+ tm_borders(alpha = .4)+ tm_compass()+   tm_layout(title = "Central School Enrollment",legend.text.size = 1.1,legend.title.size = 1.4, legend.position = c("right","top"), frame = FALSE)

#merge Higher degree education
demo_3 <- select(demo,"objectid","distname","MBA.Colleges","MBA.Colleges.Seats","MCA.Colleges","MCA.Colleges.Seats","Pharmacy.Colleges","Pharmacy.Colleges.Seats","B.Ed..Colleges","B.Ed..Colleges.Seats","Law.Colleges","Law.Colleges.Seats")
demo_3[is.na(demo_3)]=0
View(demo_3)
mergedshp_csv3 <- merge(mapData, demo_3, by.x="objectid", by.y = "objectid")
qtm(mergedshp_csv3, fill = "MBA.Colleges",text ="distname",text.size = 0.55,text.col = "black")
qtm(mergedshp_csv3, fill = "MBA.Colleges.Seats")
qtm(mergedshp_csv3, fill = "MCA.Colleges",text ="distname",text.size = 0.55,text.col = "black")
qtm(mergedshp_csv3, fill = "MCA.Colleges.Seats")
qtm(mergedshp_csv3, fill = "Pharmacy.Colleges",text ="distname",text.size = 0.55,text.col = "black")
qtm(mergedshp_csv3, fill = "Pharmacy.Colleges.Seats")
qtm(mergedshp_csv3, fill = "B.Ed..Colleges",text ="distname",text.size = 0.55,text.col = "black")
qtm(mergedshp_csv3, fill = "B.Ed..Colleges.Seats")
qtm(mergedshp_csv3, fill = "Law.Colleges",text ="distname",text.size = 0.55,text.col = "black")
qtm(mergedshp_csv3, fill = "Law.Colleges.Seats")
tm_shape(mergedshp_csv3) + tm_fill("MBA.Colleges",palette = "YlGnBu",style = "quantile",title = "MBA COLLEGES")+tm_text("distname",size = 0.6, auto.placement = F, legend.size.show = FALSE)+ tm_borders(alpha = .4)+ tm_compass()+   tm_layout(title = "Telangana MBA Education",legend.outside = TRUE,legend.text.size = 1.1,legend.title.size = 1.4, legend.position = c("left","top"), frame = FALSE)
tm_shape(mergedshp_csv3) + tm_fill("MCA.Colleges",palette = "YlOrRd",style = "quantile",title = "MCA COLLEGES")+tm_text("distname",size = 0.6, auto.placement = F, legend.size.show = FALSE)+ tm_borders(alpha = .4)+ tm_compass()+   tm_layout(title = "Telangana MCA Education",legend.outside = TRUE,legend.text.size = 1.1,legend.title.size = 1.4, legend.position = c("left","top"), frame = FALSE)
tm_shape(mergedshp_csv3) + tm_fill("Pharmacy.Colleges",palette = "-Greens",style = "quantile",title = "Phramacy COLLEGES")+tm_text("distname",size = 0.6, auto.placement = F, legend.size.show = FALSE)+ tm_borders(alpha = .4)+ tm_compass()+   tm_layout(title = "Telangana Pharmacy Education",legend.outside = TRUE,legend.text.size = 1.1,legend.title.size = 1.4, legend.position = c("left","top"), frame = FALSE)
tm_shape(mergedshp_csv3) + tm_fill("B.Ed..Colleges",palette = "-Reds",style = "quantile",title = "B.Ed COLLEGES")+tm_text("distname",size = 0.6, auto.placement = F, legend.size.show = FALSE)+ tm_borders(alpha = .4)+ tm_compass()+   tm_layout(title = "Telangana B.Ed Education",legend.outside = TRUE,legend.text.size = 1.1,legend.title.size = 1.4, legend.position = c("left","top"), frame = FALSE)
tm_shape(mergedshp_csv3) + tm_fill("Law.Colleges",palette = "YlOrRd",style = "quantile",title = "Law COLLEGS")+tm_text("distname",size = 0.6, auto.placement = F, legend.size.show = FALSE)+ tm_borders(alpha = .4)+ tm_compass()+   tm_layout(title = "Telangana Law Education",legend.outside = TRUE,legend.text.size = 1.1,legend.title.size = 1.4, legend.position = c("left","top"), frame = FALSE)


mergedshp_csv4 <- merge(mapData, demo, by.x="objectid",by.y="objectid")
qtm(mergedshp_csv4, fill ="Upper.Primary.Schools")
qtm(mergedshp_csv4, fill ="Upper.Primary.Schools.Enrollment")
qtm(mergedshp_csv4, fill ="High.Schools")
qtm(mergedshp_csv4, fill ="High.Schools.Enrollment")
tm_shape(mergedshp_csv4) + tm_fill("Upper.Primary.Schools",palette = "Reds",style = "quantile",title = "% with a UPS")+
  tm_borders(alpha=.4)+
  tm_compass()+
  tm_layout(title = "Telangana",legend.text.size = 1.1,legend.title.size = 1.4, legend.position = c("right","top"), frame = FALSE)
tm_shape(mergedshp_csv4) + tm_fill("Upper.Primary.Schools.Enrollment",palette = "Reds",style = "quantile",title = "% with a UPSE")+
  tm_borders(alpha=.4)+
  tm_compass()+
  tm_layout(title = "Telangana",legend.text.size = 1.1,legend.title.size = 1.4, legend.position = c("right","top"), frame = FALSE)
tm_shape(mergedshp_csv4) + tm_fill("High.Schools",palette = "Reds",style = "quantile",title = "% with a HS")+
  tm_borders(alpha=.4)+
  tm_compass()+
  tm_layout(title = "Telangana",legend.text.size = 1.1,legend.title.size = 1.4, legend.position = c("right","top"), frame = FALSE)
tm_shape(mergedshp_csv4) + tm_fill("High.Schools.Enrollment",palette = "Reds",style = "quantile",title = "% with a HSE")+
  tm_borders(alpha=.4)+
  tm_compass()+
  tm_layout(title = "Telangana",legend.outside = TRUE,legend.text.size = 1.1,legend.title.size = 1.4, legend.position = c("left","top"), frame = FALSE)
tm_shape(mergedshp_csv4) + tm_fill("Engineering.Colleges",palette = "Reds",style = "quantile",title = "ENGINEERING COLLEGES")+tm_text("distname",size = 0.6, auto.placement = F, legend.size.show = FALSE)+
  tm_borders(alpha=.4)+
  tm_compass()+
  tm_layout(title = "Engg in Telangana",legend.outside = TRUE,legend.text.size = 1.1,legend.title.size = 1.4, legend.position = c("left","top"), frame = FALSE)




#literacy rate of Male and Female in Telangana
setwd("C:\\Users\\dell\\Desktop\\Rajat_Mini_Project\\NEW(PROJECT)")
demo_4 <- read.csv("literacy_rate.csv")
View(demo_4)

Literacydata <- merge(mapData,demo_4, by.x = "objectid", by.y = "objectid")
plot(mapData)
Literacydata.plot <- merge(mapData,Literacydata,by.x = "objectid", by.y = "Males")
Literacydata.plot <- merge(mapData,Literacydata,by.x = "objectid", by.y = "Females")
tm_shape(Literacydata.plot)+tm_borders(alpha=.4)
tm_shape(Literacydata.plot)+tm_borders(alpha=.4)
tm_shape(Literacydata.plot)+tm_fill("Males",palette = "-Greens") 
tm_shape(Literacydata.plot)+tm_fill("Males",palette = "Reds") 







#literacy plotting by dots
mapData <- readOGR(choose.files(caption = "Select Shapfile",multi = FALSE))
Literacydata.plot <- merge(mapData, Literacydata, by.x = "objectid", by.y ="Literacy.Rate.Males")
Literacydata.plot <- merge(mapData, Literacydata, by.x = "objectid", by.y ="Literacy.Rate.Females")
Literacydata.plot <- merge(mapData, Literacydata, by.x = "objectid", by.y ="distname")
tm_shape(Literacydata.plot)+
  tm_borders(alpha = .4)+
  tm_shape(Literacydata.plot)+
  tm_dots(col = "Literacy.Rate.Males", size = 0.2, palette = "-Greens", style = "quantile")

tm_shape(Literacydata.plot)+
  tm_borders(alpha = .4)+
  tm_shape(Literacydata.plot)+
  tm_dots(col = "Literacy.Rate.Females", size = 0.2, palette = "-Reds", style = "quantile")
#Literacy of both males and females are wuite good, we can say that telanagana has decent literacy rate.

#Literacy plotting through bubles
tm_shape(Literacydata.plot) + tm_borders(alpha=.4) +
  tm_shape(Literacydata.plot) + tm_bubbles(size = 0.2, col = "Literacy.Rate.Females", 
                                      palette = "Blues", style = "quantile", legend.size.show = FALSE, title.col
                                      = "LiteracyrateFemale") +
  tm_layout(legend.text.size = 1.1, legend.title.size = 1.4, frame = FALSE)
tm_shape(Literacydata.plot) + tm_borders(alpha=.4) +
  tm_shape(Literacydata.plot) + tm_bubbles(size = 0.2, col = "Literacy.Rate.Males", 
                                           palette = "Blues", style = "quantile", legend.size.show = FALSE, title.col
                                           = "Literacyratemen") +
  tm_layout(legend.outside = TRUE, legend.text.size = 1.1, legend.title.size = 1.4, frame = FALSE)
######################################################################################################




#Normal plot(demo)
plot(demo$Longititude,demo$Latitude)
plot(demo$Primary.Schools)
plot(demo$Primary.Schools.Enrollment)
plot(demo$Upper.Primary.Schools)
plot(demo$Upper.Primary.Schools.Enrollment)
plot(demo$High.Schools)
plot(demo$High.Schools.Enrollment)
plot(demo$Model.Schools)
plot(demo$Model.Schools.Enrollment)
plot(demo$Central.Schools)
plot(demo$Central.Schools.Enrollment)
plot(demo$Junior.Colleges,demo$Degree.Colleges)
plot(demo$Law.Colleges)
plot(demo$Law.Colleges.Seats)
plot(demo$MBA.Colleges)
plot(demo$MBA.Colleges.Seats)
plot(demo$B.Ed..Colleges)
plot(demo$B.Ed..Colleges.Seats)
plot(demo$MCA.Colleges)
plot(demo$MCA.Colleges.Seats)
plot(demo$Engineering.Colleges)
plot(demo$Engineering.Colleges.Seats)



##################################################################################################
#LEAFLET - FOR BETTER VISUALIZATION AND PLOTTING
#plotting of districts

leaflet()%>%
  addTiles()%>%
  setView(lng = 78.48371, lat = 17.3713 , zoom = 10) %>%
  addMarkers(lng = 78.48371, lat = 17.3713,popup = "Telangana it is!")%>%
  addPolygons(data=mapData,color="gold",fillColor="gray",fillOpacity = 0.75,weight = 1)

setwd("C:\\Users\\dell\\Desktop\\Rajat_Mini_Project\\NEW(PROJECT)")
District.points <- read.csv("District_Latlong.csv")
View(District.points)

sDistrict.points <- District.points%>%
  sf::st_as_sf(coords = c("Lon","Lat"), crs = 4326)
View(District.points)

plot <- leaflet::leaflet(data = District.points)%>% #create leaflet object
  leaflet::addTiles()%>% #add base map
  leaflet::addMarkers()%>%
  addPolygons(data=mapData,color="gold",fillColor="gray",fillOpacity = 0.75,weight = 1)#add data layer - markers  
plot

#preape a html site
htmltools::save_html(plot,"leaflet_practice1.html")
getwd()


palPwr <- leaflet::colorFactor(palette = c("JANGAON" = "red", "MANCHERIAL" = "goldenrod", "WARANGAL" = "steelblue", "	
BHADRADRI" = "green", "	
HYDERABAD" = "purple", "KARIMNAGAR" = "Yellow", "NIZAMABAD" = "pink","MEDAK" = "maroon", "RANGAREDDY" = "gray", "NALGONDA" = "Violet", "NAGARKURNOOL" = "Chocolate", "ADILABAD" = "brown", "KOMARAM" = "darkturquoise","NIRMAL" = "darkorange","JAGTIAL" = "darkviolet","KAMAREDDY" = "deeppink2","WARANGAL" = "darkgreen","JAYASHANKAR" = "coral4","	
PEDDAPALLI" = "chocolate4","	
RAJANNA" = "burlywood2","SANGAREDDY" = "cornsilk1","SIDDIPET" = "cornflowerblue","	
MAHABUBABAD" = "cyan2","KHAMMAM" = "darkgray","	
SURYAPET" = "darkorchid","JOGULAMBA" = "deepskyblue3","WANAPARTHY" = "darkred","	
YADADRI" = "darkslategray","	
MEDCHAL" = "darkslategray1","VIKARABAD" = "darkslategray2","MAHABUBNAGAR" = "darkorange4"),domain =  District.points$District)

plot<-leaflet(District.points)%>%
  addProviderTiles("CartoDB.Positron")%>% # Consider also "Stamen.Toner"
  addCircleMarkers(radius = 10, # size of the dots
                   fillOpacity = .7, # alpha of the dots
                   stroke = FALSE, # no outline
                   popup = ~htmlEscape(District),
                   color=palPwr(District.points$District),
                   clusterOptions = markerClusterOptions())%>%
  addPolygons(data=mapData,color="gold",fillColor="gray",fillOpacity = 0.75,weight = 1)%>%


  leaflet::addLegend(position = "bottomright",
                     values=~District, # data frame column for legend
                     opacity=.7, # alpha of the legend
                     pal= palPwr, #palette declared earlier
                     title="District") %>% #Legend title
  leaflet.extras::addResetMapButton()
plot


####################################################################################################
#while comparing with the schools. Telangana is very quite famous for primary and secondary education. While going through the wikipedia earlier the situation was very worst in eduavtion.
#As the number of primary schools have been increased and the rate of literacy also been increaing.
setwd("C:\\Users\\dell\\Desktop\\Rajat_Mini_Project\\NEW(PROJECT)")
Comparison.points <- read.csv("comparison.csv")
View(Comparison.points)

sComparison.points <- Comparison.points%>%
  sf::st_as_sf(coords = c("Lon","Lat"), crs = 4326)
View(Comparison.points)

plot <- leaflet::leaflet(data = Comparison.points)%>% #create leaflet object
  leaflet::addTiles()%>% #add base map
  leaflet::addMarkers()%>%
  addPolygons(data=mapData,color="gold",fillColor="gray",fillOpacity = 0.75,weight = 1)#add data layer - markers  
plot

#preape a html site
htmltools::save_html(plot,"leaflet_practice2.html")
getwd()



palPwr <- leaflet::colorFactor(palette=c("1-10"="cyan","10-20"="orange","20-30"="yellow","30-40"="blue","40-50"="red","50-60"="green","60-70"="salmon","70-80"="yellow","80-90"="violet","100-180"="chocolate"),domain = Comparison.points$Primary.Schools)




plot<-leaflet(Comparison.points)%>%
  addProviderTiles("CartoDB.Positron")%>% # Consider also "Stamen.Toner"
  addCircleMarkers(radius = 10, # size of the dots
                   fillOpacity = .7, # alpha of the dots
                   stroke = FALSE, # no outline
                   popup = ~htmlEscape(distname),
                   color=palPwr(Comparison.points$Primary.Schools),
                   clusterOptions = markerClusterOptions())%>%
  addPolygons(data=mapData,color="gold",fillColor="gray",fillOpacity = 0.75,weight = 1)%>%
  
  
  leaflet::addLegend(position = "bottomright",
                     values=~Primary.Schools, # data frame column for legend
                     opacity=.7, # alpha of the legend
                     pal= palPwr, #palette declared earlier
                     title="No of Primary Schools") %>% #Legend title
  leaflet.extras::addResetMapButton()
plot

#######################################################################################################################

setwd("C:\\Users\\dell\\Desktop\\Rajat_Mini_Project\\NEW(PROJECT)")
Comparison.points <- read.csv("comparison.csv")
View(Comparison.points)

sComparison.points <- Comparison.points%>%
  sf::st_as_sf(coords = c("Lon","Lat"), crs = 4326)
View(Comparison.points)

plot <- leaflet::leaflet(data = Comparison.points)%>% #create leaflet object
  leaflet::addTiles()%>% #add base map
  leaflet::addMarkers()%>%
  addPolygons(data=mapData,color="gold",fillColor="gray",fillOpacity = 0.75,weight = 1)#add data layer - markers  
plot

#preape a html site
htmltools::save_html(plot,"leaflet_practice3.html")
getwd()


palPwr <- leaflet::colorFactor(palette=c("1-3"="cyan","4-7"="orange","8-10"="yellow","11-13"="blue","14-17"="red","18-21"="green"),domain = Comparison.points$Model.Schools)




plot<-leaflet(Comparison.points)%>%
  addProviderTiles("CartoDB.Positron")%>% # Consider also "Stamen.Toner"
  addCircleMarkers(radius = 10, # size of the dots
                   fillOpacity = .7, # alpha of the dots
                   stroke = FALSE, # no outline
                   popup = ~htmlEscape(distname),
                   color=palPwr(Comparison.points$Model.Schools),
                   clusterOptions = markerClusterOptions())%>%
  addPolygons(data=mapData,color="gold",fillColor="gray",fillOpacity = 0.75,weight = 1)%>%
  
  
  leaflet::addLegend(position = "bottomright",
                     values=~Model.Schools, # data frame column for legend
                     opacity=.7, # alpha of the legend
                     pal= palPwr, #palette declared earlier
                     title="No of Model Schools") %>% #Legend title
  leaflet.extras::addResetMapButton()
plot

######################################################################################################
setwd("C:\\Users\\dell\\Desktop\\Rajat_Mini_Project\\NEW(PROJECT)")
Comparison.points <- read.csv("comparison.csv")
View(Comparison.points)

sComparison.points <- Comparison.points%>%
  sf::st_as_sf(coords = c("Lon","Lat"), crs = 4326)
View(Comparison.points)

plot <- leaflet::leaflet(data = Comparison.points)%>% #create leaflet object
  leaflet::addTiles()%>% #add base map
  leaflet::addMarkers()%>%
  addPolygons(data=mapData,color="gold",fillColor="gray",fillOpacity = 0.75,weight = 1)#add data layer - markers  
plot

#preape a html site
htmltools::save_html(plot,"leaflet_practice4.html")
getwd()


palPwr <- leaflet::colorFactor(palette=c("1-3"="cyan","4-7"="orange","8-10"="yellow","11-13"="blue","14-17"="red","18-21"="green"),domain = Comparison.points$Central.Schools)




plot<-leaflet(Comparison.points)%>%
  addProviderTiles("CartoDB.Positron")%>% # Consider also "Stamen.Toner"
  addCircleMarkers(radius = 10, # size of the dots
                   fillOpacity = .7, # alpha of the dots
                   stroke = FALSE, # no outline
                   popup = ~htmlEscape(distname),
                   color=palPwr(Comparison.points$Central.Schools),
                   clusterOptions = markerClusterOptions())%>%
  addPolygons(data=mapData,color="gold",fillColor="gray",fillOpacity = 0.75,weight = 1)%>%
  
  
  leaflet::addLegend(position = "bottomright",
                     values=~Central.Schools, # data frame column for legend
                     opacity=.7, # alpha of the legend
                     pal= palPwr, #palette declared earlier
                     title="No of central Schools") %>% #Legend title
  leaflet.extras::addResetMapButton()
plot

######################################################################################################
#comparison for higher education if we compare the number of colleges. It is comparetivrly less and not that famous to work.
setwd("C:\\Users\\dell\\Desktop\\Rajat_Mini_Project\\NEW(PROJECT)")
Comparison.points <- read.csv("comparison.csv")
View(Comparison.points)

sComparison.points <- Comparison.points%>%
  sf::st_as_sf(coords = c("Lon","Lat"), crs = 4326)
View(Comparison.points)

plot <- leaflet::leaflet(data = Comparison.points)%>% #create leaflet object
  leaflet::addTiles()%>% #add base map
  leaflet::addMarkers()%>%
  addPolygons(data=mapData,color="gold",fillColor="gray",fillOpacity = 0.75,weight = 1)#add data layer - markers  
plot

#preape a html site
htmltools::save_html(plot,"leaflet_practice5.html")
getwd()

palPwr <- leaflet::colorFactor(palette=c("0"="cyan","1"="orange","2"="yellow","3"="blue","10-13"="red","17"="green","49-60" = "azure3"),domain = Comparison.points$Engineering.Colleges)





plot<-leaflet(Comparison.points)%>%
  addProviderTiles("CartoDB.Positron")%>% # Consider also "Stamen.Toner"
  addCircleMarkers(radius = 10, # size of the dots
                   fillOpacity = .7, # alpha of the dots
                   stroke = FALSE, # no outline
                   popup = ~htmlEscape(distname),
                   color=palPwr(Comparison.points$Engineering.Colleges),
                   clusterOptions = markerClusterOptions())%>%
  addPolygons(data=mapData,color="gold",fillColor="gray",fillOpacity = 0.75,weight = 1)%>%
  
  
  leaflet::addLegend(position = "bottomright",
                     values=~Engineering.Colleges, # data frame column for legend
                     opacity=.7, # alpha of the legend
                     pal= palPwr, #palette declared earlier
                     title="No of Engineering Colleges") %>% #Legend title
  leaflet.extras::addResetMapButton()
plot


########################################################################################################
#Total number of Pharmacy colleges
setwd("C:\\Users\\dell\\Desktop\\Rajat_Mini_Project\\NEW(PROJECT)")
Comparison.points <- read.csv("comparison.csv")
View(Comparison.points)

sComparison.points <- Comparison.points%>%
  sf::st_as_sf(coords = c("Lon","Lat"), crs = 4326)
View(Comparison.points)

plot <- leaflet::leaflet(data = Comparison.points)%>% #create leaflet object
  leaflet::addTiles()%>% #add base map
  leaflet::addMarkers()%>%
  addPolygons(data=mapData,color="gold",fillColor="gray",fillOpacity = 0.75,weight = 1)#add data layer - markers  
plot

#preape a html site
htmltools::save_html(plot,"leaflet_practice6.html")
getwd()

palPwr <- leaflet::colorFactor(palette=c("0"="cyan","1"="orange","2"="yellow","3"="blue","8-24"="red","17"="green","49-60" = "azure3"),domain = Comparison.points$Pharmacy.Colleges)





plot<-leaflet(Comparison.points)%>%
  addProviderTiles("CartoDB.Positron")%>% # Consider also "Stamen.Toner"
  addCircleMarkers(radius = 10, # size of the dots
                   fillOpacity = .7, # alpha of the dots
                   stroke = FALSE, # no outline
                   popup = ~htmlEscape(distname),
                   color=palPwr(Comparison.points$Pharmacy.Colleges),
                   clusterOptions = markerClusterOptions())%>%
  addPolygons(data=mapData,color="gold",fillColor="gray",fillOpacity = 0.75,weight = 1)%>%
  
  
  leaflet::addLegend(position = "bottomright",
                     values=~Pharmacy.Colleges, # data frame column for legend
                     opacity=.7, # alpha of the legend
                     pal= palPwr, #palette declared earlier
                     title="No of Pharmacy Colleges") %>% #Legend title
  leaflet.extras::addResetMapButton()
plot

###################################################################################################
##########################################################################################
#total number of MBA colleges
setwd("C:\\Users\\dell\\Desktop\\Rajat_Mini_Project\\NEW(PROJECT)")
Comparison.points <- read.csv("comparison.csv")
View(Comparison.points)

sComparison.points <- Comparison.points%>%
  sf::st_as_sf(coords = c("Lon","Lat"), crs = 4326)
View(Comparison.points)

plot <- leaflet::leaflet(data = Comparison.points)%>% #create leaflet object
  leaflet::addTiles()%>% #add base map
  leaflet::addMarkers()%>%
  addPolygons(data=mapData,color="gold",fillColor="gray",fillOpacity = 0.75,weight = 1)#add data layer - markers  
plot

#preape a html site
htmltools::save_html(plot,"leaflet_practice7.html")
getwd()

palPwr <- leaflet::colorFactor(palette=c("0-3"="cyan","4-10"="orange","10-20"="yellow","20-30"="blue","40-70"="red"),domain = Comparison.points$MBA.Colleges)





plot<-leaflet(Comparison.points)%>%
  addProviderTiles("CartoDB.Positron")%>% # Consider also "Stamen.Toner"
  addCircleMarkers(radius = 10, # size of the dots
                   fillOpacity = .7, # alpha of the dots
                   stroke = FALSE, # no outline
                   popup = ~htmlEscape(distname),
                   color=palPwr(Comparison.points$MBA.Colleges),
                   clusterOptions = markerClusterOptions())%>%
  addPolygons(data=mapData,color="gold",fillColor="gray",fillOpacity = 0.75,weight = 1)%>%
  
  
  leaflet::addLegend(position = "bottomright",
                     values=~MBA.Colleges, # data frame column for legend
                     opacity=.7, # alpha of the legend
                     pal= palPwr, #palette declared earlier
                     title="No of MBA.Colleges") %>% #Legend title
  leaflet.extras::addResetMapButton()
plot


###################################################################################
#Total number of MCA colleges
setwd("C:\\Users\\dell\\Desktop\\Rajat_Mini_Project\\NEW(PROJECT)")
Comparison.points <- read.csv("comparison.csv")
View(Comparison.points)

sComparison.points <- Comparison.points%>%
  sf::st_as_sf(coords = c("Lon","Lat"), crs = 4326)
View(Comparison.points)

plot <- leaflet::leaflet(data = Comparison.points)%>% #create leaflet object
  leaflet::addTiles()%>% #add base map
  leaflet::addMarkers()%>%
  addPolygons(data=mapData,color="gold",fillColor="gray",fillOpacity = 0.75,weight = 1)#add data layer - markers  
plot

#preape a html site
htmltools::save_html(plot,"leaflet_practice8.html")
getwd()

palPwr <- leaflet::colorFactor(palette=c("0-3"="cyan","4-10"="orange","10-20"="yellow","20-30"="blue","40-70"="red"),domain = Comparison.points$MBA.Colleges)





plot<-leaflet(Comparison.points)%>%
  addProviderTiles("CartoDB.Positron")%>% # Consider also "Stamen.Toner"
  addCircleMarkers(radius = 10, # size of the dots
                   fillOpacity = .7, # alpha of the dots
                   stroke = FALSE, # no outline
                   popup = ~htmlEscape(distname),
                   color=palPwr(Comparison.points$MCA.Colleges),
                   clusterOptions = markerClusterOptions())%>%
  addPolygons(data=mapData,color="gold",fillColor="gray",fillOpacity = 0.75,weight = 1)%>%
  
  
  leaflet::addLegend(position = "bottomright",
                     values=~MCA.Colleges, # data frame column for legend
                     opacity=.7, # alpha of the legend
                     pal= palPwr, #palette declared earlier
                     title="No of MCA.Colleges") %>% #Legend title
  leaflet.extras::addResetMapButton()
plot

###########################################################################################
#Total number of B.Ed colleges
setwd("C:\\Users\\dell\\Desktop\\Rajat_Mini_Project\\NEW(PROJECT)")
Comparison.points <- read.csv("comparison.csv")
View(Comparison.points)

sComparison.points <- Comparison.points%>%
  sf::st_as_sf(coords = c("Lon","Lat"), crs = 4326)
View(Comparison.points)

plot <- leaflet::leaflet(data = Comparison.points)%>% #create leaflet object
  leaflet::addTiles()%>% #add base map
  leaflet::addMarkers()%>%
  addPolygons(data=mapData,color="gold",fillColor="gray",fillOpacity = 0.75,weight = 1)#add data layer - markers  
plot

#prearing a html site
htmltools::save_html(plot,"leaflet_practice9.html")
getwd()

palPwr <- leaflet::colorFactor(palette=c("0-3"="cyan","4-10"="orange","10-20"="yellow","20-30"="blue","40-70"="red"),domain = Comparison.points$B.Ed..Colleges)





plot<-leaflet(Comparison.points)%>%
  addProviderTiles("CartoDB.Positron")%>% # Consider also "Stamen.Toner"
  addCircleMarkers(radius = 10, # size of the dots
                   fillOpacity = .7, # alpha of the dots
                   stroke = FALSE, # no outline
                   popup = ~htmlEscape(distname),
                   color=palPwr(Comparison.points$B.Ed..Colleges),
                   clusterOptions = markerClusterOptions())%>%
  addPolygons(data=mapData,color="gold",fillColor="gray",fillOpacity = 0.75,weight = 1)%>%
  
  
  leaflet::addLegend(position = "bottomright",
                     values=~B.Ed..Colleges, # data frame column for legend
                     opacity=.7, # alpha of the legend
                     pal= palPwr, #palette declared earlier
                     title="No of B.Ed..Colleges") %>% #Legend title
  leaflet.extras::addResetMapButton()
plot


###########################################################################################
#plotting total number of law colleges on the leaflet to get an clear idea.
setwd("C:\\Users\\dell\\Desktop\\Rajat_Mini_Project\\NEW(PROJECT)")
Comparison.points <- read.csv("comparison.csv")
View(Comparison.points)

sComparison.points <- Comparison.points%>%
  sf::st_as_sf(coords = c("Lon","Lat"), crs = 4326)
View(Comparison.points)

plot <- leaflet::leaflet(data = Comparison.points)%>% #create leaflet object
  leaflet::addTiles()%>% #add base map
  leaflet::addMarkers()%>%
  addPolygons(data=mapData,color="gold",fillColor="gray",fillOpacity = 0.75,weight = 1)#add data layer - markers  
plot

#preape a html site
htmltools::save_html(plot,"leaflet_practice10.html")
getwd()

palPwr <- leaflet::colorFactor(palette=c("0-3"="cyan","4-10"="orange","10-20"="yellow","20-30"="blue","40-70"="red"),domain = Comparison.points$Law.Colleges)





plot<-leaflet(Comparison.points)%>%
  addProviderTiles("CartoDB.Positron")%>% # Consider also "Stamen.Toner"
  addCircleMarkers(radius = 10, # size of the dots
                   fillOpacity = .7, # alpha of the dots
                   stroke = FALSE, # no outline
                   popup = ~htmlEscape(distname),
                   color=palPwr(Comparison.points$Law.Colleges),
                   clusterOptions = markerClusterOptions())%>%
  addPolygons(data=mapData,color="gold",fillColor="gray",fillOpacity = 0.75,weight = 1)%>%
  
  
  leaflet::addLegend(position = "bottomright",
                     values=~B.Ed..Colleges, # data frame column for legend
                     opacity=.7, # alpha of the legend
                     pal= palPwr, #palette declared earlier
                     title="No of Law.Colleges") %>% #Legend title
  leaflet.extras::addResetMapButton()
plot





#first let prepare a leaflet
leaflet()%>%
  addTiles()%>%
  setView(lng = 78.48371, lat = 17.3713 , zoom = 10) %>%
  addMarkers(lng = 78.48371, lat = 17.3713,popup = "Telangana it is!")%>%
  addPolygons(data=mapData,color="gold",fillColor="gray",fillOpacity = 0.75,weight = 1)

#############################################################################################################33333
#After analyzing all the higher education. I have plotted all the reputed colleges.As hyderabad is the capital of telangana and also being highlited with every education course. I have marked all the famous sector which includes from secondary to higher eduaction also government schools as well as colleges. 

#set path
setwd("C:\\Users\\dell\\Desktop\\Rajat_Mini_Project\\NEW(PROJECT)")
df <- read.csv("DF_R(MAP)2.csv")
View(df)
"fleat plot"
sdf <- df%>%
  sf::st_as_sf(coords = c("Lon","Lat"), crs = 4326)
View(df)

plot <- leaflet::leaflet(data = df)%>% #create leaflet object
  leaflet::addTiles()%>% #add base map
  leaflet::addMarkers()%>%
  addPolygons(data=mapData,color="gold",fillColor="gray",fillOpacity = 0.75,weight = 1)#add data layer - markers  
plot

#preape a html site

getwd()

#adding colours
palPwr <- leaflet::colorFactor(palette = c("MBA" = "red", "MCA" = "goldenrod", "LAW" = "steelblue", "MSC" = "green", "	
PHARMACY" = "purple", "ENGINNERING" = "Yellow", "B.ED" = "pink","Primary Schools" = "maroon", "Government School" = "gray", "Jr College" = "Violet", "Govt College" = "Chocolate", "School" = "brown"), domain = df$Branch)


plot<-leaflet(df)%>%
  addProviderTiles("CartoDB.Positron")%>% # Consider also "Stamen.Toner"
  addCircleMarkers(radius = 10, # size of the dots
                   fillOpacity = .7, # alpha of the dots
                   stroke = FALSE, # no outline
                   popup = ~htmlEscape(Name),
                   color=palPwr(df$Branch),
                   clusterOptions = markerClusterOptions())%>%
  addPolygons(data=mapData,color="gold",fillColor="gray",fillOpacity = 0.75,weight = 1)%>%
  
  
  leaflet::addLegend(position = "bottomright",
                     values=~Branch, # data frame column for legend
                     opacity=.7, # alpha of the legend
                     pal= palPwr, #palette declared earlier
                     title="Branch") %>% #Legend title
  leaflet.extras::addResetMapButton()
plot



df <- df %>%
  dplyr::mutate(label = paste0("<b>", htmlEscape(df$Name), "</b> <br>",
                               "Be sure to check ",
                               '<a href="', df$Link, '"target="_blank">the website page</a>.')) # again, note the combination of single & double quote

ikonka <- leaflet::makeIcon(iconUrl = "https://static.toiimg.com/thumb/msid-80717064,imgsize-89476,width-400,resizemode-4/80717064.jpg", # url to icon
                            iconWidth = 50, iconHeight = 50) # sizing as required


plot <- leaflet(df) %>%
  addProviderTiles("CartoDB.Positron") %>%
  addMarkers(popup = ~label,
             clusterOptions = markerClusterOptions(),
             icon = ikonka) %>%
  addPolygons(data=mapData,color="gold",fillColor="gray",fillOpacity = 0.75,weight = 1)%>%
  
  leaflet::addLegend(position = "bottomright",
                     values=~Branch, # data frame column for legend
                     opacity=.7, # alpha of the legend
                     pal= palPwr, #palette declared earlier
                     title="Branch") %>% #Legend title
  leaflet.extras::addResetMapButton()
plot

htmltools::save_html(plot,"leaflet_practice(branch).html")
